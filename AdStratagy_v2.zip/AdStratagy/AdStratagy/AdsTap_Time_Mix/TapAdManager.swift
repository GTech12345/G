//
//  AdManager.swift
//  AdStratagy
//
//  Created by Milan B. Savaliya on 05/02/25.
//

import GoogleMobileAds
import Foundation

class TapAdManager: NSObject, GADFullScreenContentDelegate {
    
    static let shared = TapAdManager()
    
    var interstitial: GADInterstitialAd?
    var currentSession = FirebaseBuilder.session1!
    private var tapCount = 0
    // Handle tap and show ads based on logic
    private var isFirstAdShown = false // Track if first ad has been shown

    private override init() {
        super.init()
    }
    
    // Override the existing setupTimers to ensure clean state
    func setupData(isMix:Bool = false) {
        // Then set new values and start timer
        if isMix {
            currentSession = FirebaseBuilder.defaultSession!
        } else {
            currentSession = FirebaseBuilder.session1!
        }
        
        // ✅ Preload the ad if startTapCount is between 1 and 4
        if (1...4).contains(currentSession.startTapCount ?? 0) && !isFirstAdShown {
            loadInterstitialAd()
        }
        
    }

    // Load an interstitial ad
    func loadInterstitialAd() {
        // do not load if value is -1
        if currentSession.startTapCount == -1 || currentSession.startTapCount == 0 {
            return
        }
        
        let adUnitID = "ca-app-pub-3940256099942544/4411468910" // Replace with your AdMob Interstitial Ad Unit ID
        print("Interstitial ad Request successfully")
        GADInterstitialAd.load(withAdUnitID: adUnitID, request: GADRequest()) { [weak self] ad, error in
            if let error = error {
                print("Failed to load interstitial ad with error: \(error.localizedDescription)")
                return
            }
            self?.interstitial = ad
            self?.interstitial?.fullScreenContentDelegate = self  // Set delegate here
            print("Interstitial ad loaded successfully")
        }
    }

    // Show the ad if it's loaded
    func showAd() {
        guard let interstitial = interstitial else {
            print("Ad not loaded yet.")
            return
        }
        // Show the interstitial ad
        if let windowScene = UIApplication.shared.connectedScenes.first as? UIWindowScene {
            if let rootViewController = windowScene.windows.first(where: { $0.isKeyWindow })?.rootViewController {
                interstitial.present(fromRootViewController: rootViewController)
            }
        }
    }

    func handleTap(isBackClick: Bool = false) {
        if !(currentSession.isBackTap ?? false) && isBackClick { return }

        tapCount += 1

        let startTapCount = currentSession.startTapCount ?? 0
        let repeatTapCount = currentSession.repeatTapCount ?? 0

        let halfStartTap = startTapCount / 2
        
        // 1️⃣ Show first ad and reset tap count
        if !isFirstAdShown && tapCount == startTapCount {
            showAd()
            isFirstAdShown = true
            tapCount = 0
            return
        } else if !isFirstAdShown {
            // 🔹 Load ad immediately if repeatTapCount is between 1 and 4
//            if (1...4).contains(startTapCount) {
//                loadInterstitialAd()
//            } else {
                if startTapCount >= 5, tapCount == halfStartTap {
                    loadInterstitialAd()
                }
//            }
        }

        // If repeatTapCount == -1, do not show any ads
        guard isFirstAdShown, repeatTapCount >= 0 else { return }

        let halfRepeatTap = repeatTapCount / 2

        // 2️⃣ Load ad at halfRepeatTap if repeatTapCount > 5
        if repeatTapCount >= 5, tapCount == halfRepeatTap {
            loadInterstitialAd()
        }

        // 3️⃣ Show ad at full repeatTapCount taps and reset
        if tapCount == repeatTapCount + 1 { // ✅ Fix: Correct tapCount check
            showAd()
            tapCount = 0
            
            // 🔹 Load ad immediately if repeatTapCount is between 1 and 4
            if (1...4).contains(repeatTapCount) {
                loadInterstitialAd()
            }
        }
    }


    // MARK: - GADFullScreenContentDelegate Methods
    func adDidDismissFullScreenContent(_ ad: any GADFullScreenPresentingAd) {
        print("Interstitial ad was dismissed.")
    }
    
    func ad(_ ad: any GADFullScreenPresentingAd, didFailToPresentFullScreenContentWithError error: any Error) {
        print("Interstitial ad failed to present with error: \(error.localizedDescription)")
    }
    
    func adWillPresentFullScreenContent(_ ad: any GADFullScreenPresentingAd) {
        print("Interstitial ad will present.")
        interstitial = nil
    }

}
