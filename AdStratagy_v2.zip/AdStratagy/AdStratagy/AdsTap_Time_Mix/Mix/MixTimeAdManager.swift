//
//  TimeAdManager.swift
//  AdStratagy
//
//  Created by Milan B. Savaliya on 07/02/25.
//


import GoogleMobileAds
import Foundation

class MixTimeAdManager: NSObject, GADFullScreenContentDelegate {
    
    private var startTimer: Timer?
//    private var repeatTimer: Timer?
    private var startTimeCount: Int = 0
    private var repeatTimeCount: Int = 0
    private var isAdLocked = true
    var isBackTap: Bool = false

    static let shared = MixTimeAdManager()
    
    // Override the existing setupTimers to ensure clean state
    func setupData(isFromReset: Bool = false) {
        isBackTap = FirebaseBuilder.session1!.isBackTap ?? false
        if isFromReset {
            self.startTimeCount = FirebaseBuilder.session1?.repeatTimeCount ?? -1
            self.repeatTimeCount = 0
        } else {
            self.startTimeCount = FirebaseBuilder.session1?.startTimeCount ?? -1
            self.repeatTimeCount = FirebaseBuilder.defaultSession?.repeatTimeCount ?? -1
        }
        
        startFirstTimer()
    }
    
    func resetData() {
        mixInterstitial = nil
        isAdLocked = true
        setupData(isFromReset: true)
    }
    
    func resetTimers() {
        startTimer?.invalidate()
        startTimer = nil
//        repeatTimer?.invalidate()
//        repeatTimer = nil
    }
    
    // Start the start timer count (e.g., counts from 1 to 20)
    private func startFirstTimer() {
        resetTimers()
        if startTimeCount == 0 || startTimeCount == -1 {
            return
        }
        var counter = 0
        isAdLocked = true
        var adLoaded = false  // Flag to ensure ad is loaded only once
        
        if (1...14).contains(self.startTimeCount) {
            self.loadInterstitialAd()
            adLoaded = true
        }
        
        startTimer = Timer.scheduledTimer(withTimeInterval: 1, repeats: true) { timer in
            counter += 1
            print("Start Timer: \(counter)")
            if counter >= self.startTimeCount {
                self.startTimer?.invalidate()
                self.startTimer = nil
                self.isAdLocked = false
            }
            
            if !adLoaded && counter >= (self.startTimeCount / 2) && !(1...14).contains(self.startTimeCount) {
                self.loadInterstitialAd()
                adLoaded = true  // Set flag to true to prevent loading the ad again
            }
        }
        
    }
    
    // This is called when the user taps to show the ad
    func handleTap(isBackClick: Bool = false) {
        
        if mixInterstitial == nil {
            print("Ad cannot be shown")
            return
        }
        if !isBackTap && isBackClick {
            return
        }
        if isAdLocked {
            print("Ad cannot be shown it's Locked")
            return
        }
        showAd()
    }
    
    // Show the ad (this is where you'd invoke the ad SDK)
    func loadInterstitialAd() {
        // Check if start_time_count is 0
        if startTimeCount == 0 || startTimeCount == -1 {
            print("Skipping ad load due to start_time_count being 0.")
            return
        }
        
        if mixInterstitial != nil {
            return
        }
        
        let adUnitID = "ca-app-pub-3940256099942544/4411468910" // Replace with your AdMob mixInterstitial Ad Unit ID
        if isMixadLoading {
            print("Mixad Time Loading")
            return
        }
        print("mixInterstitial ad Request successfully")
        // Load the mixInterstitial ad
        isMixadLoading = true
        GADInterstitialAd.load(withAdUnitID: adUnitID, request: GADRequest()) { [weak self] ad, error in
            if let error = error {
                print("Failed to load mixInterstitial ad with error: \(error.localizedDescription)")
                return
            }
            isMixadLoading = false
            print("Mixad Time Loaded")
            mixInterstitial = ad
            mixInterstitial?.fullScreenContentDelegate = self  // Set delegate here
            print("mixInterstitial ad loaded successfully")
        }
    }
    
    func showAd() {
        guard let mixInterstitial = mixInterstitial else {
            print("Ad not loaded yet.")
            return
        }
        // Show the mixInterstitial ad
        if let windowScene = UIApplication.shared.connectedScenes.first as? UIWindowScene {
            if let rootViewController = windowScene.windows.first(where: { $0.isKeyWindow })?.rootViewController {
                mixInterstitial.present(fromRootViewController: rootViewController)
            }
        }
    }
    
    // Start the repeat timer
//    private func startRepeatTimer() {
//        var counter = 0
//        var adLoaded = false  // Flag to ensure ad is loaded only once
//        isAdLocked = true
//        if (1...14).contains(self.repeatTimeCount) {
//            self.loadInterstitialAd()
//            adLoaded = true
//        }
//        repeatTimer = Timer.scheduledTimer(withTimeInterval: 1, repeats: true) { timer in
//            counter += 1
//            print("Repeat Timer: \(counter)")
//            // Preload the ad after half of the repeat time (repeatTimeCount / 2), but only once
//            if !adLoaded && counter >= (self.repeatTimeCount / 2) && !(1...14).contains(self.repeatTimeCount) {
//                self.loadInterstitialAd()
//                adLoaded = true  // Set flag to true to prevent loading the ad again
//            }
//            // Invalidate the timer when the counter reaches the repeat time count
//            if counter >= self.repeatTimeCount {
//                self.repeatTimer?.invalidate()
//                self.repeatTimer = nil
//                self.isAdLocked = false
//            }
//        }
//    }
    
    // MARK: - GADFullScreenContentDelegate Methods
    func adDidDismissFullScreenContent(_ ad: any GADFullScreenPresentingAd) {
        print("mixInterstitial ad was dismissed.")
        // Restart the cycle with repeat_time_count after ad dismissal
        resetData()
        MixTapAdManager.shared.resetData()
    }
    
    func ad(_ ad: any GADFullScreenPresentingAd, didFailToPresentFullScreenContentWithError error: any Error) {
        print("mixInterstitial ad failed to present with error: \(error.localizedDescription)")
    }
    
    func adWillPresentFullScreenContent(_ ad: any GADFullScreenPresentingAd) {
        resetTimers()
    }
}
