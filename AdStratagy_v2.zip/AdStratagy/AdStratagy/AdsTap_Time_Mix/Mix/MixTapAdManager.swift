//
//  MixTapAdManager.swift
//  AdStratagy
//
//  Created by Milan B. Savaliya on 07/02/25.
//


import GoogleMobileAds
import Foundation

var mixInterstitial: GADInterstitialAd?
var isMixadLoading: Bool = false

class MixTapAdManager: NSObject, GADFullScreenContentDelegate {
    
    static let shared = MixTapAdManager()
    
    private var tapCount = 0
    // Handle tap and show ads based on logic
    private var isFirstAdShown = false // Track if first ad has been shown

    var startTapCount: Int = -1
    var repeatTapCount: Int = -1
    var isBackTap: Bool = false
    
    private override init() {
        super.init()
    }
    
    // Override the existing setupTimers to ensure clean state
    func setupData(isFromReset:Bool = false) {
        
        isBackTap = FirebaseBuilder.session1!.isBackTap ?? false
        if isFromReset {
            startTapCount = FirebaseBuilder.session1?.repeatTapCount ?? 0
            repeatTapCount = -1
            tapCount = -1
            // ✅ Preload the ad if startTapCount is between 1 and 4
            if (1...4).contains(startTapCount) {
                loadInterstitialAd()
            }
        } else {
            startTapCount = FirebaseBuilder.session1?.startTapCount ?? 0
            repeatTapCount = FirebaseBuilder.session1?.repeatTapCount ?? 0
            tapCount = 0
            // ✅ Preload the ad if startTapCount is between 1 and 4
            if (1...4).contains(startTapCount) && !isFirstAdShown {
                loadInterstitialAd()
            }
        }
    }

    func resetData() {
        isFirstAdShown = false
        tapCount = 0
        setupData(isFromReset: true)
    }
    
    // Load an mixInterstitial ad
    func loadInterstitialAd() {
        // do not load if value is -1
        if startTapCount == -1 || startTapCount == 0 {
            return
        }
        
        if mixInterstitial != nil {
            return
        }
        
        let adUnitID = "ca-app-pub-3940256099942544/4411468910" // Replace with your AdMob mixInterstitial Ad Unit ID
        print("mixInterstitial ad Request successfully")
        if isMixadLoading {
            print("Mixad Tap Loading")
            return
        }
        isMixadLoading = true
        GADInterstitialAd.load(withAdUnitID: adUnitID, request: GADRequest()) { [weak self] ad, error in
            if let error = error {
                print("Failed to load mixInterstitial ad with error: \(error.localizedDescription)")
                return
            }
            isMixadLoading = false
            print("Mixad Tap Loaded")
            mixInterstitial = ad
            mixInterstitial?.fullScreenContentDelegate = self  // Set delegate here
            print("mixInterstitial ad loaded successfully")
        }
    }

    // Show the ad if it's loaded
    func showAd() {
        guard let mixInterstitial = mixInterstitial else {
            print("Ad not loaded yet.")
            return
        }
        // Show the mixInterstitial ad
        if let windowScene = UIApplication.shared.connectedScenes.first as? UIWindowScene {
            if let rootViewController = windowScene.windows.first(where: { $0.isKeyWindow })?.rootViewController {
                mixInterstitial.present(fromRootViewController: rootViewController)
            }
        }
    }

    func handleTap(isBackClick: Bool = false) {
        if !isBackTap && isBackClick { return }

        tapCount += 1

        let startTapCount = startTapCount
//        let repeatTapCount = repeatTapCount

        let halfStartTap = startTapCount / 2
        
        // 1️⃣ Show first ad and reset tap count
        if !isFirstAdShown && tapCount == startTapCount {
            showAd()
            isFirstAdShown = true
            tapCount = 0
            return
        } else if !isFirstAdShown {
            // 🔹 Load ad immediately if repeatTapCount is between 1 and 4
//            if (1...4).contains(startTapCount) {
//                loadInterstitialAd()
//            } else {
                if startTapCount >= 5, tapCount == halfStartTap {
                    loadInterstitialAd()
                }
//            }
        }

        // If repeatTapCount == -1, do not show any ads
//        guard isFirstAdShown, repeatTapCount >= 0 else { return }
//
//        let halfRepeatTap = repeatTapCount / 2
//
//        // 2️⃣ Load ad at halfRepeatTap if repeatTapCount > 5
//        if repeatTapCount >= 5, tapCount == halfRepeatTap {
//            loadInterstitialAd()
//        }
//
//        // 3️⃣ Show ad at full repeatTapCount taps and reset
//        if tapCount == repeatTapCount + 1 { // ✅ Fix: Correct tapCount check
//            showAd()
//            tapCount = 0
//            
//            // 🔹 Load ad immediately if repeatTapCount is between 1 and 4
//            if (1...4).contains(repeatTapCount) {
//                loadInterstitialAd()
//            }
//        }
    }


    // MARK: - GADFullScreenContentDelegate Methods
    func adDidDismissFullScreenContent(_ ad: any GADFullScreenPresentingAd) {
        print("mixInterstitial ad was dismissed.")
        MixTimeAdManager.shared.resetData()
        resetData()
    }
    
    func ad(_ ad: any GADFullScreenPresentingAd, didFailToPresentFullScreenContentWithError error: any Error) {
        print("mixInterstitial ad failed to present with error: \(error.localizedDescription)")
    }

    func adWillPresentFullScreenContent(_ ad: any GADFullScreenPresentingAd) {
        MixTimeAdManager.shared.resetTimers()
        print("Present")
    }
}
