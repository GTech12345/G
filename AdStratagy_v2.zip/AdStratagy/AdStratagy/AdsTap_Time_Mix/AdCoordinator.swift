//
//  AdCoordinator.swift
//  AdStratagy
//
//  Created by Milan B. Savaliya on 05/02/25.
//


import Foundation
import GoogleMobileAds

class AdCoordinator {
    static let shared = AdCoordinator()
    
    private var currentApproach: String?
    
    private init() {}
    
    func setupAdsBasedOnConfig() {
        // Load Firebase config values first
        FirebaseBuilder.loadAllValues()
        self.setupAds(for: "mix")
    }
    
    private func setupAds(for approach: String) {
        // Set new approach
        currentApproach = approach
        
        // Setup new approach
        switch approach.lowercased() {
        case "tap":
            print("Setting up tap-based ads")
            TapAdManager.shared.setupData()
        case "time":
            print("Setting up time-based ads")
            TimeAdManager.shared.setupData()
//            TimeAdManager.shared.loadInterstitialAd()
        case "mix":
            print("Setting up mixed approach ads")
            MixTapAdManager.shared.setupData()
            MixTimeAdManager.shared.setupData()
//            TapAdManager.shared.setupData(isMix: true)
//            TapAdManager.shared.loadInterstitialAd()
//            TimeAdManager.shared.setupData(isMix: true)
//            TimeAdManager.shared.loadInterstitialAd()

        default:
            print("Unknown approach: \(approach)")
        }
    }
    
    func handleTap(isBackClick: Bool = false) {
        guard let approach = currentApproach else { return }
        
        switch approach.lowercased() {
        case "tap":
            TapAdManager.shared.handleTap(isBackClick: isBackClick)
        case "time":
            TimeAdManager.shared.handleTap(isBackClick: isBackClick)
        case "mix":
            MixTapAdManager.shared.handleTap(isBackClick: isBackClick)
            MixTimeAdManager.shared.handleTap(isBackClick: isBackClick)
            break
        default:
            break
        }
    }
}
