//
//  TimeAdManager.swift
//  AdStratagy
//
//  Created by Milan B. Savaliya on 05/02/25.
//

import GoogleMobileAds
import Foundation

class TimeAdManager: NSObject, GADFullScreenContentDelegate {
    
    private var startTimer: Timer?
    private var repeatTimer: Timer?
    private var startTimeCount: Int = 0
    private var repeatTimeCount: Int = 0
    var interstitial: GADInterstitialAd?
    private var isAdLocked = true
    var currentSession = FirebaseBuilder.session2!

    static let shared = TimeAdManager()
    
    // Override the existing setupTimers to ensure clean state
    func setupData(isMix:Bool = false) {
        // Then set new values and start timer
        if isMix {
            self.startTimeCount = FirebaseBuilder.defaultSession?.startTimeCount ?? -1
            self.repeatTimeCount = FirebaseBuilder.defaultSession?.repeatTimeCount ?? -1
            currentSession = FirebaseBuilder.defaultSession!

        } else {
            self.startTimeCount = FirebaseBuilder.session1?.startTimeCount ?? -1
            self.repeatTimeCount = FirebaseBuilder.session1?.repeatTimeCount ?? -1
            currentSession = FirebaseBuilder.session1!
        }
        
        startFirstTimer()
    }

    func cleanup() {
        // Invalidate and remove all timers
        startTimer?.invalidate()
        startTimer = nil
        
        repeatTimer?.invalidate()
        repeatTimer = nil
    }
    
    // Start the start timer count (e.g., counts from 1 to 20)
    private func startFirstTimer() {
        if startTimeCount == 0 || startTimeCount == -1 {
            return
        }
        var counter = 0
        isAdLocked = true
        var adLoaded = false  // Flag to ensure ad is loaded only once
        
        if (1...14).contains(self.startTimeCount) {
            self.loadInterstitialAd()
            adLoaded = true
        }
        
        startTimer = Timer.scheduledTimer(withTimeInterval: 1, repeats: true) { timer in
            counter += 1
            print("Start Timer: \(counter)")
            if counter >= self.startTimeCount {
                self.startTimer?.invalidate()
                self.startTimer = nil
                self.isAdLocked = false
            }
            
            if !adLoaded && counter >= (self.startTimeCount / 2) && !(1...14).contains(self.startTimeCount) {
                self.loadInterstitialAd()
                adLoaded = true  // Set flag to true to prevent loading the ad again
            }
        }
        
    }
    
    // This is called when the user taps to show the ad
    func handleTap(isBackClick: Bool = false) {
        
        if interstitial == nil {
            print("Ad cannot be shown")
            return
        }
        if !(currentSession.isBackTap ?? false) && isBackClick {
            return
        }
        if isAdLocked {
            print("Ad cannot be shown it's Locked")
            return
        }
        showAd()
    }
    
    // Show the ad (this is where you'd invoke the ad SDK)
    func loadInterstitialAd() {
        // Check if start_time_count is 0
        if startTimeCount == 0 || startTimeCount == -1 {
            print("Skipping ad load due to start_time_count being 0.")
            return
        }
        
        let adUnitID = "ca-app-pub-3940256099942544/4411468910" // Replace with your AdMob Interstitial Ad Unit ID
        
        print("Interstitial ad Request successfully")
        // Load the interstitial ad
        GADInterstitialAd.load(withAdUnitID: adUnitID, request: GADRequest()) { [weak self] ad, error in
            if let error = error {
                print("Failed to load interstitial ad with error: \(error.localizedDescription)")
                return
            }
            self?.interstitial = ad
            self?.interstitial?.fullScreenContentDelegate = self  // Set delegate here
            print("Interstitial ad loaded successfully")
        }
    }
    
    func showAd() {
        guard let interstitial = interstitial else {
            print("Ad not loaded yet.")
            return
        }
        // Show the interstitial ad
        if let windowScene = UIApplication.shared.connectedScenes.first as? UIWindowScene {
            if let rootViewController = windowScene.windows.first(where: { $0.isKeyWindow })?.rootViewController {
                interstitial.present(fromRootViewController: rootViewController)
            }
        }
    }
    
    // MARK: - GADFullScreenContentDelegate Methods
    func adDidDismissFullScreenContent(_ ad: any GADFullScreenPresentingAd) {
        print("Interstitial ad was dismissed.")
        // Restart the cycle with repeat_time_count after ad dismissal
        self.startRepeatTimer()
    }
    
    func ad(_ ad: any GADFullScreenPresentingAd, didFailToPresentFullScreenContentWithError error: any Error) {
        print("Interstitial ad failed to present with error: \(error.localizedDescription)")
    }
    
    // Start the repeat timer
    private func startRepeatTimer() {
        var counter = 0
        var adLoaded = false  // Flag to ensure ad is loaded only once
        isAdLocked = true
        if (1...14).contains(self.repeatTimeCount) {
            self.loadInterstitialAd()
            adLoaded = true
        }
        repeatTimer = Timer.scheduledTimer(withTimeInterval: 1, repeats: true) { timer in
            counter += 1
            print("Repeat Timer: \(counter)")
            // Preload the ad after half of the repeat time (repeatTimeCount / 2), but only once
            if !adLoaded && counter >= (self.repeatTimeCount / 2) && !(1...14).contains(self.repeatTimeCount) {
                self.loadInterstitialAd()
                adLoaded = true  // Set flag to true to prevent loading the ad again
            }
            // Invalidate the timer when the counter reaches the repeat time count
            if counter >= self.repeatTimeCount {
                self.repeatTimer?.invalidate()
                self.repeatTimer = nil
                self.isAdLocked = false
            }
        }
    }
}
