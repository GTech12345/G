//
//  FirebaseBuilder.swift
//  AdStratagy
//
//  Created by Milan B. Savaliya on 05/02/25.
//

import Foundation

struct FirebaseConfig: Codable {
    let approach: String?
    let startTapCount: Int?
    let repeatTapCount: Int?
    let startTimeCount: Int?
    let repeatTimeCount: Int?
    let isBackTap: Bool?

    enum CodingKeys: String, CodingKey {
        case approach
        case startTapCount = "start_tap_count"
        case repeatTapCount = "repeat_tap_count"
        case startTimeCount = "start_time_count"
        case repeatTimeCount = "repeat_time_count"
        case isBackTap = "is_back_tap"
    }

    init(from decoder: Decoder) throws {
        let container = try decoder.container(keyedBy: CodingKeys.self)

        approach = try container.decodeIfPresent(String.self, forKey: .approach)
        isBackTap = try container.decodeIfPresent(Bool.self, forKey: .isBackTap)

        startTapCount = FirebaseConfig.convertToInt(from: container, key: .startTapCount)
        repeatTapCount = FirebaseConfig.convertToInt(from: container, key: .repeatTapCount)
        startTimeCount = FirebaseConfig.convertToInt(from: container, key: .startTimeCount)
        repeatTimeCount = FirebaseConfig.convertToInt(from: container, key: .repeatTimeCount)
    }

    private static func convertToInt(from container: KeyedDecodingContainer<CodingKeys>, key: CodingKeys) -> Int? {
        if let intValue = try? container.decodeIfPresent(Int.self, forKey: key) {
            return intValue
        }
        if let stringValue = try? container.decodeIfPresent(String.self, forKey: key), let intValue = Int(stringValue) {
            return intValue
        }
        return nil
    }
}


typealias FirebaseData = [String: FirebaseConfig]

class FirebaseBuilder {
    
    static var configData: FirebaseData?
    static var session1: FirebaseConfig?
    static var session2: FirebaseConfig?
    static var defaultSession: FirebaseConfig?
    
    static func loadAllValues() {
        let jsonString = """
        {
          "s1": {
            "approach": "tap",
            "start_tap_count": "6",
            "repeat_tap_count": "6",
            "start_time_count": "30",
            "repeat_time_count": "20",
            "is_back_tap": true
          },
          "s2": {
            "approach": "time",
            "start_tap_count": "2",
            "repeat_tap_count": "1",
            "start_time_count": "60",
            "repeat_time_count": "30",
            "is_back_tap": true
          },
          "default": {
            "approach": "mix",
            "start_tap_count": "2",
            "repeat_tap_count": "0",
            "start_time_count": "60",
            "repeat_time_count": "30",
            "is_back_tap": true
          }
        }
        """
        
        guard let jsonData = jsonString.data(using: .utf8) else { return }
        
        do {
            let decoder = JSONDecoder()
            configData = try decoder.decode(FirebaseData.self, from: jsonData)
            
            session1 = configData?["s1"]
            session2 = configData?["s2"]
            defaultSession = configData?["default"]
        } catch {
            print("Error parsing JSON: \(error)")
        }
    }
}
